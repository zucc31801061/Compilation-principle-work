/* opxx(a,b) OP##a is the enumerate no of operator b */
opxx(PLUS, " + " ) 
opxx(MINUS, " - ") 
opxx(MULT, " * ") 
opxx(DIV, " / ") 
opxx(EXPON, " ^ ") 
opxx(ASGN, " = ") 
