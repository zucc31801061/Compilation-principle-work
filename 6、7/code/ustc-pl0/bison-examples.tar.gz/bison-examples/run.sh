#!/bin/sh
bin/$1 <test/$2
